import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainslider',
  templateUrl: './mainslider.component.html',
  styleUrls: ['./mainslider.component.css']
})
export class MainsliderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
