import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-requestpoc',
  templateUrl: './requestpoc.component.html',
  styleUrls: ['./requestpoc.component.css']
})
export class RequestpocComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
