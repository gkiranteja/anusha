import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onlinedemo',
  templateUrl: './onlinedemo.component.html',
  styleUrls: ['./onlinedemo.component.css']
})
export class OnlinedemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
