import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recognitions',
  templateUrl: './recognitions.component.html',
  styleUrls: ['./recognitions.component.css']
})
export class RecognitionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
