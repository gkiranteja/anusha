import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-successcases',
  templateUrl: './successcases.component.html',
  styleUrls: ['./successcases.component.css']
})
export class SuccesscasesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
